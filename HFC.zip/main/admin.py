from django.contrib import admin
from .models import Team, Blog

admin.site.register(Team)
admin.site.register(Blog)
